#ifndef TESTE_H
#define TESTE_H

#include <stdio.h>

void testa_ambos_merge_sort(int vetor[], size_t tam);
void testa_ambos_quick_sort(int vetor[], size_t tam);
void testa_ambos_heap_sort(int vetor[], size_t tam);

#endif // TESTE_H
